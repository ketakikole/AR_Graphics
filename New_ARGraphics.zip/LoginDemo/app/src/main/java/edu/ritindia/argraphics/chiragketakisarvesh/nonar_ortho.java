package edu.ritindia.argraphics.chiragketakisarvesh;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;

//import com.example.prolab.logindemo.R;

public class nonar_ortho extends AppCompatActivity {

    ListView listView;
    ImageView lastClickedRowImage;
    ImageView imageView;
    int s;
    String[] country={"Model 1","Model 2","Model 3","Model 4","Model 5"};
    int[] lion={
            R.drawable.four,
            R.drawable.seco,
            R.drawable.capture,
            R.drawable.first,
            R.drawable.first
    };

    public nonar_ortho() {
        // Required empty public constructor
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nonar_ortho);
        // getArguments();
        // textView.setText(getArguments().getString("message"));
        // String s=getArguments().getString("message");
        // Toast.makeText(getContext(),s,Toast.LENGTH_SHORT);

        //toolBar=view.findViewById(R.id.toolbar);
       // toolBar.setTitle(getResources().getString(R.strin g.app_name));
        listView=findViewById(R.id.listview1);
        MyAdapter_nonar myAdapter=new MyAdapter_nonar(this,country,lion);
       listView.setAdapter(myAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
                Intent intent=new Intent(nonar_ortho.this,web_code.class);

                //Intent intent=new Intent(,Main2Activity.class);
                switch (i)
                {
                    case 0:
                        s=i;
                        break;
                    case 1:
                        s=i;
                        break;
                    case 2:
                        s=i;
                        break;
                    case 3:
                        s=i;
                        break;
                    case 4:
                        s=i;
                        break;

                }
                intent.putExtra("one",s);
                startActivity(intent);
            }
        });


    }

}


