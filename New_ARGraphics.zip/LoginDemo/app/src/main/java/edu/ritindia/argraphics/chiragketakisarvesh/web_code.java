package edu.ritindia.argraphics.chiragketakisarvesh;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

//import com.example.prolab.logindemo.R;

public class web_code extends AppCompatActivity {

    WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_code);
        Bundle bundle = getIntent().getExtras();
        int  s = bundle.getInt("one");
        //webView = findViewById(R.id.webview);
        // Toast.makeText(web_code.this, s, Toast.LENGTH_SHORT).show();
        // String url="file:///android_asset/ortho3.html" ;


        webView=new WebView(this);
        //webView.getSettings().setJavaScriptEnabled(true);
        //webView.clearCache(true);
        //webView.getSettings().setDomStorageEnabled(true);
        switch (s)
        {
            case 0:
                webView.loadUrl("file:///android_asset/iso1.html");
                break;
            case 1:
                webView.loadUrl("file:///android_asset/iso2.html");
                break;
            case 2:
                webView.loadUrl("file:///android_asset/iso3.html");
                break;
            case 3:
                webView.loadUrl("file:///android_asset/iso4.html");
                break;
            case 4:
                webView.loadUrl("file:///android_asset/iso5.html");
                break;
        }
       // webView.loadUrl("file:///android_asset/vv.html");
        webView.getSettings().setJavaScriptEnabled(true);
        setContentView(webView);
        // webView.setWebViewClient(new web_code.MyBrowser());
    }



}