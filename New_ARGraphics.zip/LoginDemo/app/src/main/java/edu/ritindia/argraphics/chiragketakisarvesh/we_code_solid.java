package edu.ritindia.argraphics.chiragketakisarvesh;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

//import com.example.prolab.logindemo.R;

public class we_code_solid extends AppCompatActivity {

    WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_code_iso);
        Bundle bundle = getIntent().getExtras();
        int  s = bundle.getInt("one");
        //webView = findViewById(R.id.webview);
        // Toast.makeText(web_code.this, s, Toast.LENGTH_SHORT).show();
        // String url="file:///android_asset/ortho3.html" ;


        webView=new WebView(this);
        //webView.getSettings().setJavaScriptEnabled(true);
        //webView.clearCache(true);
        //webView.getSettings().setDomStorageEnabled(true);
        switch (s)
        {
            case 0:
                webView.loadUrl("file:///android_asset/cone.html");
                break;
            case 1:
                webView.loadUrl("file:///android_asset/cube.html");
                break;
            case 2:
                webView.loadUrl("file:///android_asset/pyrmid.html");
                break;
            case 3:
                webView.loadUrl("file:///android_asset/iso6.html");
                break;

        }
        // webView.loadUrl("file:///android_asset/vv.html");
        webView.getSettings().setJavaScriptEnabled(true);
        setContentView(webView);
        // webView.setWebViewClient(new web_code.MyBrowser());
    }



}