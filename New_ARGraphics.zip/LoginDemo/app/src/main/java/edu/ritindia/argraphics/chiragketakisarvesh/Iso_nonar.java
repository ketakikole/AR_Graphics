package edu.ritindia.argraphics.chiragketakisarvesh;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

//import com.example.prolab.logindemo.R;

public class Iso_nonar extends AppCompatActivity {

    TextView textView;
    ListView listView;
    ImageView lastClickedRowImage;
    ImageView imageView;
    int s;
    String[] country={"Model 1","Model 2","Model 3","Model 4"};
    int[] lion={R.drawable.capture6,
            R.drawable.za,
            R.drawable.capturrre,
            R.drawable.first
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_iso_nonar);

        listView=findViewById(R.id.listview1);
        MyAdapter_iso myAdapter=new MyAdapter_iso(Iso_nonar.this,country,lion);
        listView.setAdapter(myAdapter);

        // imageView=(ImageView)findViewById(R.id.imageView3);
        // listView[0].setOnItemClickListener
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
                //Intent intent=new Intent(getActivity(),Main6Activity.class);
                Intent intent=new Intent(Iso_nonar.this,web_code_iso.class);
                //Intent intent=new Intent(,Main2Activity.class);
                switch (i)
                {
                    case 0:
                        s=i;
                        break;
                    case 1:
                        s=i;
                        break;
                    case 2:
                        s=i;
                        break;
                    case 3:
                        s=i;
                        break;
                    case 4:
                        s=i;
                        break;
                }
                intent.putExtra("one",s);
                startActivity(intent);
            }
        });

    }
}
