package edu.ritindia.argraphics.chiragketakisarvesh;


import android.support.design.widget.*;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;

//import com.example.prolab.logindemo.R;

public class Main9Activity extends AppCompatActivity {

    Toolbar toolbar;
    ViewPager viewPager;
    ViewPagerAdapter6 viewPagerAdapter;
    TabLayout tabLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // Toast.makeText(getApplicationContext(),"in main2activity",Toast.LENGTH_LONG).show();
        setContentView(R.layout.activity_main8);
        toolbar=findViewById(R.id.toolBar);
        setSupportActionBar(toolbar);

        viewPager=findViewById(R.id.pager);
        viewPagerAdapter=new ViewPagerAdapter6(getSupportFragmentManager());
        viewPager.setAdapter(viewPagerAdapter);

        tabLayout=findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(viewPager);
    }
}
