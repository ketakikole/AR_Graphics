package edu.ritindia.argraphics.chiragketakisarvesh;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

//import com.example.prolab.logindemo.R;
import com.github.barteksc.pdfviewer.PDFView;

public class Question extends AppCompatActivity {

    PDFView pdfView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);
        pdfView=findViewById(R.id.pdf);
        pdfView.fromAsset("question_bank.pdf").load();

    }
}
