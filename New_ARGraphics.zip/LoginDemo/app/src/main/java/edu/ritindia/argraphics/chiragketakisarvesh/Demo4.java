package edu.ritindia.argraphics.chiragketakisarvesh;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.Button;
import android.widget.TextView;

//import com.example.prolab.logindemo.R;
import com.github.barteksc.pdfviewer.PDFView;


/**
 * A simple {@link Fragment} subclass.
 */
public class Demo4 extends Fragment  {

    TextView textView;
    Button button;
    PDFView pdfView;
    public Demo4() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_demo4,container,false);
        //  button=(Button)layout.findViewById(R.id.button);
        // button = (Button) view.findViewById(R.id.button);
        // getArguments();
        //   textView.setText(getArguments().getString("message"));
        // String s=getArguments().getString("message");
        // Toast.makeText(getContext(),s,Toast.LENGTH_SHORT);

        pdfView=view.findViewById(R.id.pdf);
        pdfView.fromAsset("question_bank.pdf").load();

        return view;
    }

}
