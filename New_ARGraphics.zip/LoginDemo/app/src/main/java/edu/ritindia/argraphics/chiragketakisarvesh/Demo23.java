package edu.ritindia.argraphics.chiragketakisarvesh;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;

//import com.example.prolab.logindemo.R;


/**
 * A simple {@link Fragment} subclass.
 */
public class Demo23 extends Fragment {

    Toolbar toolBar;
    ListView listView;
    ImageView lastClickedRowImage;
    ImageView imageView;
    int s;
    String[] country={"Problem 1","problem 2","prob 3","prob 4","prob 5"};
    int[] lion={
            R.drawable.back,
            R.drawable.back,
            R.drawable.back,
            R.drawable.back,
            R.drawable.back
            };

    public Demo23() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_demo23,container,false);
        //  button=(Button)layout.findViewById(R.id.button);
        // button = (Button) view.findViewById(R.id.button);
        // textView =view.findViewById(R.id.txt_display);
        // getArguments();
        // textView.setText(getArguments().getString("message"));
        // String s=getArguments().getString("message");
        // Toast.makeText(getContext(),s,Toast.LENGTH_SHORT);

        toolBar=view.findViewById(R.id.toolbar);
        toolBar.setTitle(getResources().getString(R.string.app_name));
        listView=view.findViewById(R.id.listview1);
        //MyAdapter1 myAdapter=new MyAdapter1(getActivity(),country,lion);
       // listView.setAdapter(myAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
                Intent intent=new Intent(getActivity(),web_code.class);

                //Intent intent=new Intent(,Main2Activity.class);
                switch (i)
                {
                    case 0:
                        s=i;
                        break;
                    case 1:
                        s=i;
                        break;
                    case 2:
                        s=i;
                        break;
                    case 3:
                        s=i;
                        break;
                    case 4:
                        s=i;
                        break;

                }
                intent.putExtra("one",s);
                getActivity().startActivity(intent);
            }
        });

        return view;
    }

}
