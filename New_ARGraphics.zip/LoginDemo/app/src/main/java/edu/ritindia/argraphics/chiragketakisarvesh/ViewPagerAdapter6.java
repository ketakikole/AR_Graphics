package edu.ritindia.argraphics.chiragketakisarvesh;


import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

public class ViewPagerAdapter6 extends FragmentPagerAdapter {
    public ViewPagerAdapter6(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {

        Fragment fragment=null;

        switch (position){
            case 0: fragment=new Demo61();
                break;
            case 1: fragment=new Demo62();
                break;
            //case 2: fragment=new Demo33();
              //  break;


        }

        return fragment;
    }

    @Override
    public int getCount() {
        return 2;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        String s="";
        switch (position)
        {
            case 0:s="Theory";
                break;
            case 1:s="Assignment";
                break;

          //  case 2:s="Solids";
              //  break;


        }

        position=position+1;
        return s;
    }
}
