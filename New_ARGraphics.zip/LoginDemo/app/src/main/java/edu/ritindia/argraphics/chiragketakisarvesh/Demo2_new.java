package edu.ritindia.argraphics.chiragketakisarvesh;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

//import com.example.prolab.logindemo.R;


/**
 * A simple {@link Fragment} subclass.
 */
public class Demo2_new extends Fragment {


    Toolbar toolBar;
    ListView listView;
    TextView textView;
    ImageView lastClickedRowImage;
    ImageView imageView;
    Fragment fragment=null;
    String s;
    String[] country={"Model 1","Model 2","Model 3","Model 4","Model 5"};
    int[] lion={R.drawable.four,
            R.drawable.seco,
            R.drawable.four,
            R.drawable.capture,
            R.drawable.first
    };
    public Demo2_new() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_demo2_new,container,false);
        //  button=(Button)layout.findViewById(R.id.button);
        // button = (Button) view.findViewById(R.id.button);
        // textView =view.findViewById(R.id.txt_display);
        // getArguments();
        // textView.setText(getArguments().getString("message"));
        // String s=getArguments().getString("message");
        // Toast.makeText(getContext(),s,Toast.LENGTH_SHORT);

       textView=view.findViewById(R.id.textView4);
        toolBar=view.findViewById(R.id.toolbar);
        toolBar.setTitle(getResources().getString(R.string.app_name));
        listView=view.findViewById(R.id.listview);
        MyAdapter myAdapter=new MyAdapter(getActivity(),country,lion);
        listView.setAdapter(myAdapter);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity(),nonar_ortho.class);
                startActivity(intent);
            }
        });
        // imageView=(ImageView)findViewById(R.id.imageView3);
        // listView[0].setOnItemClickListener
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
                Intent intent=new Intent(getActivity(),Main6Activity.class);
                //Intent intent=new Intent(getActivity(),web_code_iso.class);
                //Intent intent=new Intent(,Main2Activity.class);
                switch (i)
                {
                    case 0:
                        s="box.sfb";
                        break;
                    case 1:
                        s="box2.sfb";
                        break;
                    case 2:
                        s="box3.sfb";
                        break;
                    case 3:
                        s="four.sfb";
                        break;
                    case 4:
                        s="third.sfb";
                        break;
                }
                intent.putExtra("one",s);
                getActivity().startActivity(intent);
            }
        });


        return view;
    }

}
