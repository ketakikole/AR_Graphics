package edu.ritindia.argraphics.chiragketakisarvesh;


import android.support.design.widget.*;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;

//import com.example.prolab.logindemo.R;

public class Main4Activity extends AppCompatActivity {

    Toolbar toolbar;
    ViewPager viewPager;
    ViewPagerAdapter1 viewPagerAdapter;
    TabLayout tabLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // Toast.makeText(getApplicationContext(),"in main4activity",Toast.LENGTH_LONG).show();
        setContentView(R.layout.activity_main4);
        toolbar=findViewById(R.id.toolBar);
        setSupportActionBar(toolbar);

        viewPager=findViewById(R.id.pager1);
       // viewPagerAdapter=new ViewPagerAdapter(getSupportFragmentManager());
        viewPagerAdapter= new ViewPagerAdapter1(getSupportFragmentManager());
        viewPager.setAdapter(viewPagerAdapter);

        tabLayout=findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(viewPager);
    }
}
