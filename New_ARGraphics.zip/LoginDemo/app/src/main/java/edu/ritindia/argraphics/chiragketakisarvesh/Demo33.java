package edu.ritindia.argraphics.chiragketakisarvesh;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.content.Intent;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

//import com.example.prolab.logindemo.R;


/**
 * A simple {@link Fragment} subclass.
 */
public class Demo33 extends Fragment  {

    TextView textView;
    Button button;
    Toolbar toolBar;
    ListView listView;
    ImageView lastClickedRowImage;
    ImageView imageView;
    String s;
    String[] country={"cone","cube","cylinder","Pyramid","CYLINDER-CROSSsection","PYRAMID CUtSection"};
    int[] lion={R.drawable.capt33ure,
            R.drawable.captur33e,
            R.drawable.captur44e,
            R.drawable.pyr,
            R.drawable.cylin,
            R.drawable.captu1re
    };

    public Demo33() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_demo33,container,false);
        //  button=(Button)layout.findViewById(R.id.button);
        // button = (Button) view.findViewById(R.id.button);
        //textView =view.findViewById(R.id.txt_display);
        // getArguments();
        //   textView.setText(getArguments().getString("message"));
        // String s=getArguments().getString("message");
        // Toast.makeText(getContext(),s,Toast.LENGTH_SHORT);

        toolBar=view.findViewById(R.id.toolbar);
        toolBar.setTitle(getResources().getString(R.string.app_name));
        listView=view.findViewById(R.id.listview2);
        MyAdapter2 myAdapter=new MyAdapter2(getActivity(),country,lion);
        listView.setAdapter(myAdapter);
        // imageView=(ImageView)findViewById(R.id.imageView3);
        // listView[0].setOnItemClickListener
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
                Intent intent=new Intent(getActivity(),Main6Activity.class);

                //Intent intent=new Intent(,Main2Activity.class);
                switch (i)
                {
                    case 0:
                        s="Cone.sfb";
                        break;
                    case 1:
                        s="Cube.sfb";
                        break;
                    case 2:
                        s="Cylinder.sfb";
                        break;
                    case 3:
                        s="Pyramid.sfb";
                        break;
                    case 4:
                        s="CYLINDER-CROSSobj.sfb";
                        break;
                    case 5:
                        s="pYRAMID CUt.sfb";
                        break;


                }
                intent.putExtra("one",s);
                getActivity().startActivity(intent);
            }
        });

        return view;
    }

}
