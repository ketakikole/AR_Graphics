package edu.ritindia.argraphics.chiragketakisarvesh;



import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

public class ViewPagerAdapter1 extends FragmentPagerAdapter {
    public ViewPagerAdapter1(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {

        Fragment fragment=null;

        switch (position){
            case 0: fragment=new Demo21();
                break;
            case 1: fragment=new Demo22();
                break;

            case 2:
                fragment=new Demo2_new();
                break;

        }

        return fragment;
    }

    @Override
    public int getCount() {
        return 3;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        String s="";
        switch (position)
        {
            case 0:s="Theory";
                break;
            case 1:s="Assignment";
                break;
            case 2:s="AR";
                break;


        }

        position=position+1;
        return s;
    }
}

